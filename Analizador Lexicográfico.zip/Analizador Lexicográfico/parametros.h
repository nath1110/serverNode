//par�metros del compilador. 
//tambi�n se podr�an leer de un archivo de configuraci�n

#define MAXLINEA 1000  //tama�o m�ximo de una l�nea del programa fuente    
#define MAXPAL     21  //numero de palabras reservadas                     
#define MAXDIGIT    5  //m�ximo n�mero de d�gitos en los enteros             
#define MAXID      10  //m�xima longitud de los identificadores              
