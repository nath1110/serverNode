#include <stdio.h>

//variables globales...por el momento solo una           
extern FILE *fp; //apuntador a archivo conteniendo el programa fuente
