int error(int no);
void inicializar_espec(),imprime_token();